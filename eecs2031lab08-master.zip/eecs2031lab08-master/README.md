# eecs2031lab08
bash tasks
