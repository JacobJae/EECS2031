# eecs2031lab06
lab 06. Temperature sensor
