# eecs2031lab09
more bash scripts
