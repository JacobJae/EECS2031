# eecs2031lab05
house alarm
