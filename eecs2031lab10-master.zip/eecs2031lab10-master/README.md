# eecs2031lab10
An IoT Temperature Sensor in BASH
